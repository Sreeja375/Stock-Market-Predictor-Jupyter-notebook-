    # Stock Market Predictor (LSTM)

Run the notebook `Stock_Market_Predictor.ipynb`. It downloads AAPL data via yfinance, trains a small LSTM, and plots predictions.

Requirements in requirements.txt.
